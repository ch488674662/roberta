import pandas as pd
import codecs
from sklearn.cross_validation import train_test_split


train_lines = codecs.open('emotion/train.csv',encoding='utf-8').readlines()[1:]
train_data = pd.DataFrame({
            'id': [x[:32] for x in train_lines],
            'ocr': [x[33:].strip() for x in train_lines]})

train_label=pd.read_csv('emotion/train_label.csv',encoding='utf-8')

train_data_new=pd.merge(train_data,train_label,on='id',how='left')
train_data_new.drop(['id'],axis=1,inplace=True)
for i in range(len(list(train_data_new['ocr']))):
    # print(train_data_new.iloc[i]['ocr'])
    train_data_new.iloc[i]['ocr'] = train_data_new.iloc[i]['ocr'].replace('\t','').replace(' ','')
    # print(train_data_new.iloc[i]['ocr'])
train_df,dev_new=train_test_split(train_data_new,test_size=0.2)


dev_new.to_csv('emotion/dev.tsv',encoding='utf-8',index=False,sep='\t')
train_df.to_csv('emotion/train_df.tsv',encoding='utf-8',index=False,sep='\t')
# train_data_new.to_csv('emotion/train_new.csv',encoding='utf-8',index=False)


test_lines = codecs.open('emotion/Test_DataSet.csv',encoding='utf-8').readlines()[1:]
test_data = pd.DataFrame({
            'id': [x[:32] for x in test_lines],
            'ocr': [x[33:].strip() for x in test_lines]
})
test_data.drop(['id'],axis=1,inplace=True)
for i in range(len(list(test_data['ocr']))):
    # print(train_data_new.iloc[i]['ocr'])
    test_data.iloc[i]['ocr'] = test_data.iloc[i]['ocr'].replace('\t','').replace(' ','')
test_data.to_csv('emotion/test_new.tsv',encoding='utf-8',index=False,sep='\t')
